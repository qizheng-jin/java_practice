package com.webserver.core;

public class Text {

    public static void main(String[] args){
        String s = "hello";
        System.out.println(s.equals("hello"));
    }
}
